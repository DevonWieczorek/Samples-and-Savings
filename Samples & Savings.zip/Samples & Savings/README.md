# Samples-and-Savings
Extension for Google Chrome

Authored by Devon Wieczorek, May 2017

LANGUAGES: Javascript, jQuery

PURPOSE: Receive relevant offers for FREE samples and coupons based on your browsing history.

USAGE: Simply install the extension from the Chrome Store and continue your browsing as usual. It's that simple!

CREDITS:
- Relevancy.js: https://github.com/padolsey/relevancy.js/

TODO:
- Figure out how to clean reward keys programatically when they are retrieved
- Implement local storage for reward key/values to decrease file requests